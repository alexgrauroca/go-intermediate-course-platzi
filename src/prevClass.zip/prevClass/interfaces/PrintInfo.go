package interfaces

type PrintInfo interface {
	GetMessage() string
}
